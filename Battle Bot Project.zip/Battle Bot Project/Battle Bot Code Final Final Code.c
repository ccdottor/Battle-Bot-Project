#include "simpletools.h" 
#include "abdrive360.h"                     

int lightTop, whiteDetector1, whiteDetector2;
int TopPin = 6;
int whiteDPin1 = 9;
int whiteDPin2 = 2;

int irLeft, irRight;

int main(){
  
  low(26);
  low(27);
  drive_setRampStep(12);
   
  while(1){
    high(TopPin);
    pause(1);
    lightTop = rc_time(TopPin, 1); 
    
    high(whiteDPin1);
    pause(1);
    whiteDetector1 = rc_time(whiteDPin1, 1);
    
    high(whiteDPin2);
    pause(1);
    whiteDetector2 = rc_time(whiteDPin2, 1);
    
    //print("%d \n", whiteDetector2);
    
    //print("%d \n", lightTop);
    
    if(lightTop < 3000){                            //right side up
      freqout(11, 1, 38000);
      irLeft = input(10);                        

      freqout(0, 1, 38000);                       
      irRight = input(1);
      
      //print("%d \n", irLeft);
      //print("%d \n", irRight);
      //pause(100);
      
      if(whiteDetector1 < 3500){                    // detects a wall or pit
        if(irLeft == 0 && irRight == 0){           // wall/pit straight ahead
          drive_rampStep(-128, -128);              // full speed reverse
          drive_rampStep(128, -128);                // turn in another direction away from wall         
        }        
        else if(irRight == 0)                      // wall/pit on right
          drive_rampStep(128, -128);               // rotate left
        else if(irLeft == 0)                       // wall/pit on left
          drive_rampStep(-128, 128);               // rotate right
      }
      
      if(whiteDetector1 > 3500){                    // doesn't detect a wall
        if(irRight == 1 && irLeft == 1)            // not obstacles
          drive_rampStep(128, 128);                // go forward
        else if(irLeft == 0 && irRight == 0)       // obstacle directly forward
          drive_rampStep(128, 128);                // ATTACK!!
        else if(irRight == 0)                      // obstacle on right
          drive_speed(-16, 100);                 // ATTACK to the right
        else if(irLeft == 0)                       // obstacle on left
          drive_speed(100, -16);                  // ATTACK to the left
      }
    }  
    
    if(lightTop > 3000){                            //upside down (got flipped)
      freqout(11, 1, 38000);
      irLeft = input(10);                        

      freqout(0, 1, 38000);                       
      irRight = input(1);

      if(whiteDetector2 < 4500){                     // detects a wall or pit
        if(irRight == 1 && irLeft == 1)             // not obstacles
          drive_rampStep(-128, -128);
        if(irLeft == 0 && irRight == 0){            // wall/pit straight ahead
          drive_rampStep(128, 128);               // full speed reverse
          drive_rampStep(-128, 128);                 // turn in another direction away from wall
        }          
        else if(irRight == 0)                       // wall/pit on right
          drive_rampStep(128, -128);                // rotate left
        else if(irLeft == 0)                        // wall/pit on left
          drive_rampStep(-128, 128);                // rotate right
      }
      
      if(whiteDetector2 > 4500){                     // doesn't detect a wall
        if(irRight == 1 && irLeft == 1)             // not obstacles
          drive_rampStep(-128, -128);                 // go forward
        else if(irLeft == 0 && irRight == 0)        // obstacle directly forward
          drive_rampStep(-128, -128);                 // ATTACK!!
        else if(irRight == 0)                       // obstacle on right
          drive_speed(-100, 16);                  // ATTACK to the right
        else if(irLeft == 0)                        // obstacle on left
          drive_speed(16,-100);                   // ATTACK to the left
      }
    }    
  }  
}
